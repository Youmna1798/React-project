import React from "react";

export default function NotFound() {
  return <div>404 - No Page Found with this name </div>;
}
