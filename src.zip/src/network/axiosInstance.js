// import axios from "axios";

// export const axiosInstance = axios.create({"https://api.themoviedb.org/3/movie/popular?api_key=0635aa13dcf8f77aa3d3a659b24086cc"
//   baseURL: ,
// });
