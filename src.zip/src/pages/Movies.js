import React from "react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
// import { axiosInstance } from "../network/axiosInstance";
import axios from "axios";
import { useSelector, useDispatch } from "react-redux";
import "../loginForm.css";

export default function MoviesDetails() {
  // const params = useParams();
  const [movies, setMovies] = useState([]);
  const favIds = useSelector((state) => state.favIds);
  const dispatch = useDispatch();

  let isFav = (id) => {
    return favIds.find((el) => el === id);   //check mwgoda wala la2
  };

  let toggleFav = (id) => {
    isFav(id)
      ? dispatch({ type: "REMOVE", payload: id })   //lw mwgoda
      : dispatch({ type: "ADD", payload: id });
  };
  useEffect(() => {
    // axiosInstance
      axios
      .get("https://api.themoviedb.org/3/movie/popular?api_key=0635aa13dcf8f77aa3d3a659b24086cc&page=5")
      .then((res) => setMovies(res.data.results))
      .catch((err) => console.log(err));
  }, []);
      console.log(movies)
  return (
    <div className="container ba">
    <h1>Movies</h1>
    <hr/>
    <div className="row">
      {movies.map((movie) => {
      return (
        <div className="card col-3 offset-1" style={{width:"18 rem"}} key={movie.id}>
        <img src={`https://image.tmdb.org/t/p/w500/${movie.poster_path}`}  className="card-img-top" alt="..."/>
        <div className="card-body">
          <h5 className="card-title">{movie.title}</h5>
              <button
                className={`btn btn-primary  mx-2 ${isFav(movie.id) ? "active" : ""}`}
                onClick={() => toggleFav(movie.id)}
              >Add/Remove</button>
          <Link to={`/watchMovie/${movie.id}`} className="btn btn-primary ">Movie details</Link>
        </div>
      </div>
      );
      })}
    </div>
    </div>
    );

}


